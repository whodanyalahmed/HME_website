import pytesseract
import os
# If you don't have tesseract executable in your PATH, include the following:
pytesseract.pytesseract.tesseract_cmd = r'H:\\tesseract\\tesseract'


def ImgtoTxt(filename):
    return pytesseract.image_to_string(filename)  # Timeout after 2 seconds

wd = os.getcwd()+'\\dataset'
no_of_files = len(os.listdir(wd))
for i in range(1,no_of_files+1):
    filename = wd+'\\'+str(i)+'.png'
    print(ImgtoTxt(filename))

# print(ImgtoTxt('pen.jpeg'))
