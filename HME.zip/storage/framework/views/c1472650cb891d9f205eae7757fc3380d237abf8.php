
<?php
    $var = "Classes"
?>

<?php $__env->startSection('title'); ?>
    <?php echo e($var); ?> | Admin
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<body class="sb-nav-fixed">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dash-side-nav','data' => ['data' => ''.e($var).'']]); ?>
<?php $component->withName('dash-side-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => ''.e($var).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4"><?php echo e($var); ?></h1>
                    
  
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            <?php echo e($var); ?>

                        </div>
                        <div class="card-body">
                            <table id="feedbacktab" class="cell-border stripe hover" >
                                <thead>
                                    <tr>
                                        <th>Course Id</th>
                                        <th>Name</th>
                                        <th>Teacher Id</th>
                                        <th>Teacher name</th>
                                        <th>Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($item['id']); ?></td>
                                <td><?php echo e($item['name']); ?></td>
                                <td><?php echo e($item['t_id']); ?></td>
                                <td><?php echo e($item['t_name']); ?></td>

                                <td><a href="classedit" data-c_id="<?php echo e($item['id']); ?>"  data-t_id="<?php echo e($item['t_id']); ?>" data-c_name="<?php echo e($item['name']); ?>"  class="btn btn-outline-warning edit">Edit</a></td>
                                
                                
                            </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-area me-1"></i>
                                    Area Chart Example
                                </div>
                                <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-bar me-1"></i>
                                    Bar Chart Example
                                </div>
                                <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; <?php echo e($siteTitle); ?> 2021</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
        
  <!-- edit Modal -->
  <div class="modal fade" id="form_modal" tabindex="-1" aria-labelledby="form_modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="form_modalLabel">Edit Class <span class="fw-bold" id="classname"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <form  id="Edit_class" method="POST" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="id">
     

            <div class="row mb-md-4">
                <div class="form-group col-md-12  me-5 mb-md-0">
                    <h5 class="display-5">Change Teacher</h5>
                    <label for="from_teacher">From teacher</label>
                    <select class="form-select item" aria-label="Default select example" id="from_teacher" onchange="checkTeacher()" name="from_teacher" required>
                        <option value='' selected>select teacher</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher['t_id']); ?>"><?php echo e($teacher['t_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-md-12  mt-4 mb-md-0">
                    <label for="to_teacher">To teacher</label>
                    <select class="form-select item" aria-label="Default select example" id="to_teacher" onchange="checkTeacher()"  name="to_teacher" required>
                        <option value='' selected>select teacher</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher['t_id']); ?>"><?php echo e($teacher['t_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
     
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
       
         
    <script src="/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="/assets/demo/chart-area-demo.js"></script>
    <script src="/assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="/js/datatables-simple-demo.js"></script>
    <script>
    back = "";
    $(".edit").on('click',function(e){

        e.preventDefault();    
        // console.log(e);
        id = $(this).data('t_id');
        c_id = $(this).data('c_id');
        $("#id").val(c_id);
        name= $(this).data('c_name');
        
        $('#from_teacher').val(id).change();
        
        back = $("#from_teacher").val();
            action = $(this).select();
            href = action.attr('href');
            
            console.log(href);
            var forms = document.getElementById('Edit_class').setAttribute('action',href);


            var names = document.getElementById('classname').innerText = name;
            $("#form_modal").modal("toggle");
            return false;
        
        });
    function checkTeacher(){
        to_id = $("#to_teacher").val();
        from_id = $("#from_teacher").val();

        if(to_id == from_id){
            window.swal("Oops!","Cant select same teacher", "error")
            .then(function() {
                        $("#to_teacher").val("").change();
                        if(to_id == "" && from_id == ""){
                            location.reload();
                        }
                            });
        }
        
    }

    $("#Edit_class").submit(function(e) {

        e.preventDefault(); // avoid to execute the actual submit of the form.

            var form = $('#Edit_class');
            var url = form.attr('action');
            $("button[type=submit]").attr("disabled","disabled");
            $.ajax({
                type: "POST",
                url: url,
                data: form.serialize(), // serializes the form's elements.
                success:function(response){
                    window.swal("Success", response.msg, "success")
                            .then(function(value) {
                                location.reload();
                            });
            },
        error:function(requestObject, error, errorThrown){
            $("#form").modal('toggle');

            window.swal("Oops!",  requestObject.responseJSON.errorMsg.errorInfo[2], "error")
                    .then(function(value) {
                            location.reload();
                        });
                    

            }
    });
    
});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\learning\learning laravel\basic\HME\resources\views/admin/classes.blade.php ENDPATH**/ ?>