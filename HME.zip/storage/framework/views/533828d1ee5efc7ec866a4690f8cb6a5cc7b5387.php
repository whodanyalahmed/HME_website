

<?php
    $var = "St. Fee Details"
?>

<?php $__env->startSection('title'); ?>
    <?php echo e($var); ?> | Admin
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<body class="sb-nav-fixed">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dash-side-nav','data' => ['data' => ''.e($var).'']]); ?>
<?php $component->withName('dash-side-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => ''.e($var).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4"><?php echo e($var); ?></h1>
                    
  
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            <?php echo e($var); ?>

                        </div>
                        <div class="card-body">
                            <table id="ActiveStudents" class="cell-border compact stripe hover" >
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>S.Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Amount</th>
                                        <th>fee status</th>
                                        <th>Fee Paid</th>
                                        <th>Month</th>
                                        <th>year</th>
                                        <th class="text-center">View</th>
                                        
                                        <th>Interested in</th>
                                        <th>Not Paid/Pending/Paid</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($item['fee_id']); ?></td>
                                <td><?php echo e($item['s_id']); ?></td>
                                <td><?php echo e($item['s_name']); ?></td>
                                
                                <td><?php echo e($item['s_email']); ?></td>
                                <td><?php echo e($item['fees_amount'] + $item['fee_arrears']); ?></td>
                                
                                
                                <?php
                                $d = $item['fee_status'];
                                $s = ($d == 0) ? "not paid" : (($d == 1)  ? "paid" : "pending");
                                ?>
                                <td><?php echo e($s); ?>

                                </td>
                                <td><?php echo e(($item['fees_paid']) ? "Yes" : "No"); ?></td>
                                
                                <td><?php echo e($item['monthname']); ?></td>
                                <td><?php echo e($item['year']); ?></td>
                                <td class="text-center"><a href="<?php echo e($item['url']); ?>"   onclick="updateView(this)" data-bs-toggle="modal" data-bs-target="#view">
                                    <?php echo ($item['url'] == "")? "":"View" ?>
                                    
                                </a></td>
                                <td><?php echo e($item['modname']); ?></td>
                                
                                    
                                <td>
                                    <div class="btn-group d-flex justify-content-center" role="group" aria-label="Basic mixed styles example">
                                        <a href="notpaid/<?php echo e($item['s_id']); ?>"   onclick="update(this,<?php echo e($item['s_id']); ?>,<?php echo e($item['fee_id']); ?>)" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-outline-danger">Not Paid</a>
                                        <a href="pending/<?php echo e($item['s_id']); ?>"   onclick="update(this,<?php echo e($item['s_id']); ?>)" data-bs-toggle="modal" data-bs-target="#Pending" class="btn btn-outline-warning">Pending</a>
                                        <a href="paid/<?php echo e($item['s_id']); ?>"   onclick="update(this,<?php echo e($item['s_id']); ?>,<?php echo e($item['fee_id']); ?>)" data-bs-toggle="modal" data-bs-target="#Paid" class="btn btn-outline-success">Paid</a>
                                    </div>
                                </td>
                            </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-area me-1"></i>
                                    Area Chart Example
                                </div>
                                <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-bar me-1"></i>
                                    Bar Chart Example
                                </div>
                                <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; <?php echo e($siteTitle); ?> 2021</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
        <!-- Not paid Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Conirm disable</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Do you really wanna Not Paid?
                    </div>
                    <div class="modal-footer">
                        <form action="" method="post" id="form" name="form" class="form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" id="formVal" value="">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="delete" class="btn btn-danger">Not Paid</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Pending Modal -->
        <div class="modal fade" id="Pending" tabindex="-1" aria-labelledby="PendingLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="PendingLabel">Conirm disable</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Do you really wanna Pending?
                    </div>
                    <div class="modal-footer">
                        <form action="" method="post" id="form" name="form" class="form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" id="formVal" value="">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="delete" class="btn btn-warning">Pending</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Paid Modal -->
        <div class="modal fade" id="Paid" tabindex="-1" aria-labelledby="PaidLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="PaidLabel">Conirm disable</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Do you really wanna Paid?
                    </div>
                    <div class="modal-footer">
                        <form action="" method="post" id="form" name="form" class="form" >
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" id="formVal" value="">
                            <input type="hidden" name="fee_id" id="fee_id" value="">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="delete" class="btn btn-success">Paid</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <!-- Modal -->
<div class="modal fade" id="view" tabindex="-1" aria-labelledby="viewLabel" aria-hidden="true">
    <div class="modal-dialog ">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewLabel">Paid Screenshot</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <h3 id="cantfind"></h3>
        <img src="" alt="paid screenshot" id="Imgview" height="100%" width="100%">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
        <script>
            
          function updateView(ele){
            action = $(ele).select();
            href = action.attr('href');
            
            url = "/uploads/"+href;

            if(href == ""){
                document.getElementById("cantfind").setAttribute("class","");
                document.getElementById("cantfind").innerHTML = "<div class='alert alert-warning d-flex align-items-center container' role='alert' ><i class='fas fa-exclamation-circle mr-3'></i> Image is not Uploaded...</div>";
                document.getElementById("Imgview").setAttribute("class","hidden");
            }
            else{
                document.getElementById("cantfind").setAttribute("class","hidden");
                document.getElementById("Imgview").setAttribute("src",url);
                document.getElementById("Imgview").setAttribute("class","");
            }
            // alert(url);
          }
          function update(ele,p,fee_id = 0) {
            document.getElementById("fee_id").value = fee_id;


                action = $(ele).select();
                href = action.attr('href');
                
                // console.log(href);
                var forms = document.getElementsByName('form')
                forms.forEach(element => {
                    element.setAttribute('action','student/'+href);
                });

                var names = document.getElementsByName('id');
                names.forEach(ele => {
                    ele.setAttribute('value',p);
                });
            }
            // $("#delete").click(function(){
            // $('#form').attr('action');
            // $.ajax({url: "demo_test.txt", success: function(result){
            //     if(result.success == true){ // if true (1)
            //         setTimeout(function(){// wait for 5 secs(2)
            //             location.reload(); // then reload the page.(3)
            //         }, 5000); 
            // }});
            // });


            $(".form").submit(function(e) {

            e.preventDefault(); // avoid to execute the actual submit of the form.

            var form = $('.form');
            var url = form.attr('action');
            $("button[type=submit]").attr("disabled","disabled");
            $.ajax({
                type: "POST",
                url: url,
                data: form.serialize(), // serializes the form's elements.
                success:function(response){
                    window.swal("Success", response.msg, "success")
                            .then(function(value) {
                                location.reload();
                            });
            },
            error:function(requestObject, error, errorThrown){
                   $("#form").modal('toggle');
    
                   window.swal("Oops!",  requestObject.responseJSON.errorMsg.errorInfo[2], "error")
                         .then(function(value) {
                                location.reload();
                            });
                         
  
                }
                });
                
});



       </script>
         
    <script src="/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="/assets/demo/chart-area-demo.js"></script>
    <script src="/assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="/js/datatables-simple-demo.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\learning\learning laravel\basic\HME\resources\views/admin/ActiveStudents.blade.php ENDPATH**/ ?>