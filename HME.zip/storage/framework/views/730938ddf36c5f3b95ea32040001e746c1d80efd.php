


<?php $__env->startSection('title'); ?>
    Soemthing went wrong
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <section class="text-center  mt-5">
        <?php if($data == 0): ?>
            <main class="px-5 pt-5">
                <div class="container">

                    <div class="row">
                        
                        <div class="col-lg-12 col-md-12 ">
                            <div>
                                <h1 class="pt-5">
                                    <i class="fas fa-exclamation-circle fs-1 mb-4"></i><br>
                                    Wrong Email or Password.</h1>
                                <p class="lead">Please check either email/username or password is wrong.</p>
                            </div>
                        </div>
                        
                    </div>

                </div>
            </main>    
        <?php else: ?>
        <main class="px-5 pt-5">
            <h1><i class="fas fa-exclamation-circle fs-1 mb-4"></i><br>
                Something went wrong.</h1>
            <p class="lead">Cover is a one-page template for building simple and beautiful home pages. Download, edit the text, and add your own fullscreen background photo to make it your own.</p>
        </main>    
        <?php endif; ?>
    </section>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\learning\learning laravel\basic\HME\resources\views/something.blade.php ENDPATH**/ ?>