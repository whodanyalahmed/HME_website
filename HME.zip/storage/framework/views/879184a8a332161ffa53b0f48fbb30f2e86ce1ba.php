
<?php
    $var = "Courses Fees"
?>

<?php $__env->startSection('title'); ?>
    <?php echo e($var); ?> | Admin
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<body class="sb-nav-fixed">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dash-side-nav','data' => ['data' => ''.e($var).'']]); ?>
<?php $component->withName('dash-side-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => ''.e($var).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <div class="row">
                        <div class="col-md-6">
                            <h1 class="mt-4"><?php echo e($var); ?></h1>

                        </div>
                        <div class="col-md-6">
                            <button class="btn btn-outline-dark float-end mt-4" data-bs-toggle="modal" data-bs-target="#Message">+ Add Course</button>

                        </div>
                    </div>
                    
  
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            <?php echo e($var); ?>

                        </div>
                        <div class="card-body">
                            <table id="admissionfeetab" class="cell-border compact stripe hover" >
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>fee</th>
                                        <th>Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($item['id']); ?></td>
                                <td><?php echo e($item['name']); ?></td>
                                <td><?php echo e($item['fee']); ?></td>
                                
                                <td>
                                    
                                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                        <button 
                                        data-id="<?php echo e($item['id']); ?>"  
                                        data-name="<?php echo e($item['name']); ?>"  
                                        data-fee="<?php echo e($item['fee']); ?>"  
                                     
                                        class="btn btn-outline-warning edit_btn">Edit</button>
                                        
                                      </div>
                                </td>
                                
                            </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-area me-1"></i>
                                    Area Chart Example
                                </div>
                                <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-bar me-1"></i>
                                    Bar Chart Example
                                </div>
                                <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; <?php echo e($siteTitle); ?> 2021</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
        

        
        
       <!-- edit Modal -->
<div class="modal fade" id="form_modal" tabindex="-1" aria-labelledby="form_modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="form_modalLabel">Edit Course Fee Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form  id="coursesfee" method="POST" >
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id">
                    <div class="row mb-md-4">
                        <div class="form-group col-md-12  mb-3 mb-md-0">
                            <label for="name">Name</label>
                            <input type="text" class="form-control item" id="name" name="name" placeholder="Username" required disabled>
                        </div>
                    </div>

        
        
            
        
                    <div class="row mb-md-4">
                        <div class="form-group col-md-12  mb-3 mb-md-0">
                            <label for="fee">Fees </label>
                            <input type="text"  class="form-control item" id="fee" name="fee" placeholder="fee" required>
                        </div>
                    </div>
                
            
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="admsubmit"class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

  
  <div class="modal fade" id="Message" tabindex="-1" aria-labelledby="MessageLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="MessageLabel">Create Course</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        
<div class="modal-body">
        <form action="/admin/course" id="Add_News" method="POST" >
            <?php echo csrf_field(); ?>


  
        <div class="row mb-md-4">
            <div class="form-group col-md-12  mb-3 mb-md-0">

                <label for="heading">Course</label>
                <input type="text" class="form-control item" id="c_heading" name="course" required>
            </div>
        </div>

        <div class="row mb-md-4" id="feeComp">
            <div class="form-group col-md-12  mb-3 mb-md-0">
                <label for="c_fees">Fees </label>
                <input type="number" class="form-control item" id="c_fees" name="fees" required>
            </div>
        </div>
        <div class="container  mb-md-4">
            <div class="form-check col-md-12  mb-3 mb-md-0">
                <input class="form-check-input" type="checkbox" name="parent" value="1" onchange="CheckParent()" class="parent" id="flexCheckDefault">
                <label class="form-check-label" for="flexCheckDefault">
                Parent                
                </label>
              </div>
        </div>
        <?php
        $items = DB::select('SELECT * FROM `modules` 
 
            where parent = 0');
        ?>
        <div class="row mb-md-4" id="feeComp">
            <div class="form-group col-md-12  mb-3 mb-md-0">
                
                <label for="heading">Select parent: </label>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="parentName" value="<?php echo e($item->id); ?>" id="ra<?php echo e($item->id); ?>">
                        <label class="form-check-label" for="ra<?php echo e($item->id); ?>">
                            <?php echo e($item->name); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" id="sub">Create</button>
        </div>
    </form>

      </div>
    </div>
  </div>
</div>

        <script>
    function CheckParent(){
        var checkedValue = $('input[id=flexCheckDefault]');
        // console.log(checkedValue[0].checked)
        checkedValue = checkedValue[0]['checked'];
        console.log(checkedValue)
        if(checkedValue){
            console.log('in if')
            $('#c_fees').attr('disabled',true);
            $('input[name=parentName]').attr('disabled',true)
        }
        else{
            console.log('in else')
            $('#c_fees').attr('disabled',false);
            $('input[name=parentName]').attr('disabled',false)

        }
    }
          
$('.edit_btn').click(function(e) {
        e.preventDefault();
        
        var id = $(this).data('id');
        var name = $(this).data('name');
        var fee  = $(this).data('fee');

        // sending values to modal
        $('#id').val(id);
        $("#name").val(name);
        $("#fee").val(fee);
        
        $("#form_modal").modal('toggle');
        
    

    });


    $('#coursesfee').submit(function(e){
    
    e.preventDefault();

        form = $("#coursesfee");
        $("#admsubmit").attr("disabled","disabled");

        $.ajax({
            type : 'POST',
            url  : '/admin/coursesfee',
            data : form.serialize(),
            success:function(response){
                window.swal("Success", response.msg, "success")
                            .then(function(value) {
                               location.reload();
                            });
            },
            error:function(requestObject){
                   $("#form_modal").modal('toggle');
    
                         window.swal("Oops!",  requestObject.responseJSON.errorMsg.errorInfo[2], "error");
                            
                    // location.reload();
                                        setTimeout(() => {
                    location.reload();
                      },2000);
  
                }
        });
    });
    $('#Add_News').submit(function(e){
    
    e.preventDefault();

        form = $("#Add_News");
        action = form.attr('action');
        $("#sub").attr("disabled","disabled");

        $.ajax({
            type : 'POST',
            url  : action,
            data : form.serialize(),
            success:function(response){
                window.swal("Success", response.msg, "success")
                            .then(function(value) {
                               location.reload();
                            });
            },
            error:function(requestObject){
                   $("#Message").modal('toggle');
    
                         window.swal("Oops!",  requestObject.responseJSON.errorMsg.errorInfo[2], "error");
                            
                    // location.reload();
                                        setTimeout(() => {
                    location.reload();
                      },2000);
  
                }
        });
        
    });
       </script>
         
    <script src="/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="/assets/demo/chart-area-demo.js"></script>
    <script src="/assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="/js/datatables-simple-demo.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\learning\learning laravel\basic\HME\resources\views/admin/coursesfee.blade.php ENDPATH**/ ?>