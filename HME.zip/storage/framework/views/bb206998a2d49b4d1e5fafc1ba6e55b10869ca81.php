
<?php $__env->startSection('title'); ?>
    Log in | HME
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 

<?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<div class="registration-form">
    <form action="/students/dashboard" method="POST">
        <?php echo csrf_field(); ?>
        <h1 class="text-center mb-4">Login for students</h1>
        <div class="form-icon">
            <span><i class="far fa-user"></i></span>
        </div>
    <div class="form-group">
        <input type="text" class="form-control item" id="email" name="email" placeholder="Email">
    </div>
    <div class="form-group">
        <input type="password" class="form-control item" id="password" name="password"placeholder="Password">
    </div>

    <div class="form-group">
        <button type="submit" class="btn btn-block create-account">Log in</button>
    </div>
</form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\learning\learning laravel\basic\HME\resources\views/login.blade.php ENDPATH**/ ?>